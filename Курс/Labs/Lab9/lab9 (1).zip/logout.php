<?php
session_start();
$old_user = $_SESSION["valid_user"];  
// сохранить для проверки, регистрировался ли пользователь
unset($_SESSION["valid_user"]);
session_destroy(); 
?>
<html><body><h1>Выход из системы</h1> 
<?php
if (! empty ($old_user) ){
if (!isset($_SESSION["valid_user"]))
{ 
// если пользователь был зарегистрирован и покинул систему
echo "Вы вышли из системы<br>"; }
else { // если пользователь не может покинуть систему
echo "Could not log you out.<br>"; } } 
else { // если пользователь не был зарегистрирован, 
echo "Вы не были зарегистрированы <br>"; 
} 
?>
