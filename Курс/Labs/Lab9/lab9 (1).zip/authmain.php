<?php

session_start();

if (isset ( $_POST["name"] ) && isset ($_POST["password"] ))

{
// если пользователь как раз пытается зарегистрироваться 
// Подключаемся к серверу MySql
$connect = mysqli_connect('127.0.0.1', 'root', '', 'company') or die ("Не могу соединиться с сервером MySql");
//Выбираем БД

$query = "select * from auth where name="."\"".$_POST["name"]."\"and pass="."\"".$_POST["password"]."\"";
print    $query;
$result=mysqli_query($connect, $query);

if  (mysqli_num_rows($result) >0 )
{
// если пользователь найден в базе данных, 
// зарегистрировать его идентификатор 

$_SESSION["valid_user"] = $_POST["name"];
 
}
}
?>
<html><head>
<meta charset="utf-8">
</head><body><h1>Home page</h1>
<?php

if (isset($_SESSION["valid_user"]))
{

echo "Вы зарегистрированы как:  ".$_SESSION["valid_user"]." <br>"; 
echo "<a href=\"logout.php\">Выход</a><br>";
}
else
{
if (isset($_POST["name"])) {
// если пользователь пытался зарегистрироваться, 
// но возникла ошибка 
echo "Ошибка регистрации"; }
else {
// если пользователь либо не пытался зарегистрироваться, 
// либо покинул сайт 
echo "Вход для зарегистрированных пользователей.<br>"; }
// форма для аутентификации
echo "<form method=post action=\"authmain.php\">"; 
echo "<table>"; echo "<tr><td>Имя пользователя:</td>";
echo "<td><input type=text name=\"name\"></td></tr>"; 
echo "<tr><td>Пароль:</td>";
echo "<td><input type=password name=\"password\"></td></tr>"; 
echo "<tr><td colspan=2 align=center>" ; 
echo "<input type=submit value=\"Вход\"></td></tr>" ; 
echo "</table></form>" ;

}
?> <br>
<a href="members_only.php">Секретная страница</a>
</body></html>
