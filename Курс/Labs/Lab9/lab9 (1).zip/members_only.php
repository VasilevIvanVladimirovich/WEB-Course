<?php
session_start();
echo  "<h1>Members  only</h1>";
// проверить переменные сеанса
if (isset($_SESSION["valid_user"]))
{
echo "Доброго времени суток  ".$_SESSION["valid_user"]."! <br>";
echo "<p>Далее может идти содержание секретной страницы</p>";
}
else
{
echo "<p>Вы не являетесь зарегистрированным пользователем.</p>";
echo "<p>У Вас нет прав для просмотра данной страницы.</p>";
}




echo "<a  href=\"authmain.php\">Вернуться </a>"; 
?>
<head>
<meta charset="utf-8">
</head>
<body>
<?php
$connect = mysqli_connect('127.0.0.1', 'root', '', 'company') or die ("Не могу соединиться с сервером MySql");

// задаем кодировку по умолчанию, которая будет использоваться при обмене данными с сервером баз данных

if (!mysqli_set_charset($connect, "utf8")) {
    //printf("Ошибка при загрузке набора символов utf8: %s\n", mysqli_error($connect));
} else {
   // printf("Текущий набор символов: %s\n", mysqli_character_set_name($connect));
}
//проверяем существование переменных из формы

  if ( isset($_POST["del"] ))
    {
  $query="DELETE FROM products WHERE prod_id=". $_POST["id"];
  // print $query;
   $result=mysqli_query($connect, $query);

    }
    if ( isset($_POST["edit"] ) )
    {
   $query1= "UPDATE products SET prod_name=\"".$_POST["prod_name"]."\",prod_price=".$_POST["prod_price"]." WHERE prod_id=". $_POST["id"] ;
  // print  $query1;
    $result=mysqli_query($connect, $query1);
    }
if ( isset($_POST["name"] ) && isset ($_POST["cena"]) && isset  ($_FILES["filename"]["name"]))
{
   if($_FILES["filename"]["size"] > 1024*1024)
   {
     echo ("Размер файла превышает 1 мегабайт");
     exit;
   }
   if(@copy($_FILES["filename"]["tmp_name"],
     "img/".$_FILES["filename"]["name"]))
   {
/*
 echo("Файл успешно загружен <br>");
     echo("Характеристики файла: <br>");
     echo("Имя файла: ");
     echo($_FILES["filename"]["name"]);
     echo("<br>Размер файла: ");
     echo($_FILES["filename"]["size"]);
     echo("<br>Каталог для загрузки: ");
     echo($_FILES["filename"]["tmp_name"]);
     echo("<br>Тип файла: ");
     echo($_FILES["filename"]["type"]);
*/
   } else {
     echo("Ошибка загрузки файла");
   }

// формируем текст запроса на добавление записи путем конкатенации текста и значений переменных
//чтобы получилась ковычка для текстововго поля ее экранируем \"

$query="INSERT INTO products VALUES(null,\"".$_POST["name"]."\",".$_POST["cena"].",\"".$_FILES["filename"]["name"]."\",\"".$_SESSION["valid_user"]."\")";
//выводим текст запроса для проверки
//print $query;
//выполняем запрос на добавление записи
$result=mysqli_query($connect, $query);

}



//Выполняем запрос- выбрать все записи из таблицы products
$result=mysqli_query($connect, "SELECT * FROM products where user_name="."\"".$_SESSION["valid_user"]."\""  );
// print     "SELECT * FROM products where user_name="."\"".$_SESSION["valid_user"]."\"";
// для проверки выводим количество строк, участвующих в запросе
//$resultrow=mysqli_num_rows($result);
//print "выбрано записей-". $resultrow;
?>
<h2 align=center> У нас в продаже </h2>
<table border="0" width="80%"  align="center">
<tr>
<th> </th>
<th> Наименование</th>
<th>Цена</th>
<th>Изображение</th>
<th>Действие</th>
</tr>
<?php
while ($row=mysqli_fetch_array($result))
{
?>
<form action="members_only.php" method="post" >
<tr>
<td><input type="hidden" name="id"  size="10" value="<?php print $row["prod_id"]?>" ></td>
<td><input type="text" name="prod_name"  size="30" value="<?php print $row["prod_name"]?>"readonly></td>
<td><input type="text" name="prod_price"  size="10" value="<?php print $row["prod_price"]?>"</td>
<td><img src="img/<?php print $row["image"]?> " width="50"></td>
<td>

<input type=submit name="edit" value="Редактировать запись">
<input type=submit name="del" value="Удалить запись">

</td>
</tr>
 </form>
<?php
}
?>
</table>
<?php
mysqli_close($connect );
?>

<div style="margin:20px 300px auto; ">
    <h3>Добавить продукт </h3>
<form action=members_only.php method=post enctype=multipart/form-data>
<p>Продукт:<input type="text" name="name" maxlength="50" size="36"></p>
<p>Цена:<input type="text" name="cena" maxlength="50" size="36"></p>

<p><input type=file name="filename"> <br></p>
<input type=submit name="doupload" value="Добавить запись">
</form>
</div>
</body>
